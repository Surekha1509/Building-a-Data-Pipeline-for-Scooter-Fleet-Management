# Gans Fleet Data Pipeline

This repository contains a Cloud Run / Cloud Functions ready pipeline for collecting **Airports**, **Weather**, and **Flights** data and storing it into a MySQL (Cloud SQL) database.

## Contents
- `main.py` - Combined pipeline with HTTP endpoint that updates airports, weather, and flights
- `requirements.txt` - Python dependencies
- `Dockerfile` - Container definition for Cloud Run
- `sql_schema.sql` - SQL schema for required tables
- `sample_env.example` - Example environment variables
- `cloudscheduler_example.txt` - Example Cloud Scheduler configuration


## Quickstart (local testing)

1. Create a Python virtual environment and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. Create MySQL database and tables (use `sql_schema.sql`).

3. Set environment variables (see `sample_env.example`) or export them in your shell.

4. Run locally:
   ```bash
   python main.py
   # then open http://127.0.0.1:8080/
   ```

## Deploy to Cloud Run
1. Build and submit the container:
   ```bash
   gcloud builds submit --tag gcr.io/PROJECT_ID/gans-pipeline
   ```
2. Deploy to Cloud Run:
   ```bash
   gcloud run deploy gans-pipeline --image gcr.io/PROJECT_ID/gans-pipeline --region europe-west1 --allow-unauthenticated
   ```

## Notes
- Do NOT store secrets in source code. Use Cloud Secret Manager or environment variables in Cloud Run.
- Replace placeholder API keys and DB credentials with secure values.
