# main.py
# Combined Airports + Weather + Flights pipeline (Cloud Run / Cloud Function compatible)
# Replace placeholders in config or use environment variables / Secret Manager in production.
import os
import json
import requests
import pandas as pd
from sqlalchemy import create_engine, text
from flask import Flask, request, jsonify
from datetime import datetime
from pytz import timezone

app = Flask(__name__)

# ---------- Configuration (use env vars in production) ----------
DB_USER = os.environ.get("DB_USER", "root")
DB_PASS = os.environ.get("DB_PASS", "YOUR_DB_PASSWORD")
DB_HOST = os.environ.get("DB_HOST", "127.0.0.1")
DB_PORT = int(os.environ.get("DB_PORT", 3306))
DB_NAME = os.environ.get("DB_NAME", "etl_cities_cloud")

OPENWEATHER_KEY = os.environ.get("OPENWEATHER_KEY", "YOUR_OPENWEATHER_KEY")
AERODATABOX_RAPIDAPI_KEY = os.environ.get("AERODATABOX_RAPIDAPI_KEY", "YOUR_RAPIDAPI_KEY")

# ---------- Helpers ----------
def get_db_engine():
    url = f'mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}'
    return create_engine(url, pool_pre_ping=True)

def get_cities(engine):
    with engine.connect() as conn:
        result = conn.execute(text("SELECT city_id, city, latitude, longitude FROM cities"))
        rows = result.fetchall()
        return pd.DataFrame(rows, columns=result.keys())

def get_airports_icao(engine, city_id):
    with engine.connect() as conn:
        result = conn.execute(text("SELECT icao FROM airports WHERE city_id = :cid"), {"cid": city_id})
        return [r[0] for r in result.fetchall()]

# ---------- Airports ----------
def fetch_airports(lat, lon, radius_km=50, limit=10):
    url = f"https://aerodatabox.p.rapidapi.com/airports/search/location?lat={lat}&lon={lon}&radiusKm={radius_km}&limit={limit}&withFlightInfoOnly=false"
    headers = {
        "X-RapidAPI-Key": AERODATABOX_RAPIDAPI_KEY,
        "X-RapidAPI-Host": "aerodatabox.p.rapidapi.com"
    }
    resp = requests.get(url, headers=headers, timeout=15)
    resp.raise_for_status()
    return resp.json()

def insert_airports(airports_json, city_id, engine):
    records = []
    for airport in airports_json.get("items", []):
        icao = airport.get("icao")
        if not icao:
            continue
        records.append({"icao": icao, "city_id": city_id})
    if not records:
        return 0
    df = pd.DataFrame(records)
    with engine.begin() as conn:
        for _, row in df.iterrows():
            conn.execute(
                text("""
                    INSERT INTO airports (icao, city_id)
                    VALUES (:icao, :city_id)
                    ON DUPLICATE KEY UPDATE city_id=VALUES(city_id)
                """),
                row.to_dict()
            )
    return len(records)

# ---------- Weather ----------
def fetch_weather(city_name):
    url = f"http://api.openweathermap.org/data/2.5/forecast?q={city_name}&appid={OPENWEATHER_KEY}&units=metric"
    resp = requests.get(url, timeout=15)
    resp.raise_for_status()
    return resp.json()

def insert_weather(weather_json, city_id, engine):
    berlin_tz = timezone("Europe/Berlin")
    now = datetime.now(berlin_tz).strftime("%Y-%m-%d %H:%M:%S")
    records = []
    for item in weather_json.get("list", [])[:8]:
        records.append({
            "city_id": city_id,
            "forecast_time": item.get("dt_txt"),
            "temperature": item.get("main", {}).get("temp"),
            "forecast": item.get("weather", [{}])[0].get("main"),
            "rain_in_last_3h": item.get("rain", {}).get("3h", 0),
            "wind_speed": item.get("wind", {}).get("speed"),
            "data_retrieved_at": now
        })
    if not records:
        return 0
    df = pd.DataFrame(records)
    with engine.begin() as conn:
        for row in df.to_dict(orient="records"):
            conn.execute(text("""
                INSERT INTO weather
                (city_id, forecast_time, temperature, forecast, rain_in_last_3h, wind_speed, data_retrieved_at)
                VALUES (:city_id, :forecast_time, :temperature, :forecast, :rain_in_last_3h, :wind_speed, :data_retrieved_at)
                ON DUPLICATE KEY UPDATE
                    temperature=VALUES(temperature),
                    forecast=VALUES(forecast),
                    rain_in_last_3h=VALUES(rain_in_last_3h),
                    wind_speed=VALUES(wind_speed),
                    data_retrieved_at=VALUES(data_retrieved_at)
            """), row)
    return len(records)

# ---------- Flights ----------
def fetch_flights(icao):
    berlin_tz = timezone("Europe/Berlin")
    today = datetime.now(berlin_tz).strftime("%Y-%m-%d")
    url = f"https://aerodatabox.p.rapidapi.com/flights/airports/icao/{icao}/{today}/{today}"
    headers = {
        "X-RapidAPI-Key": AERODATABOX_RAPIDAPI_KEY,
        "X-RapidAPI-Host": "aerodatabox.p.rapidapi.com"
    }
    resp = requests.get(url, headers=headers, timeout=15)
    resp.raise_for_status()
    return resp.json()

def insert_flights(flights_json, icao, engine):
    berlin_tz = timezone("Europe/Berlin")
    records = []
    for direction in ["departures", "arrivals"]:
        for flight in flights_json.get(direction, []):
            records.append({
                "icao": icao,
                "flight_number": flight.get("flightNumber") or flight.get("number"),
                "airline": (flight.get("airline") or {}).get("name"),
                "departure_time": (flight.get("departure") or {}).get("scheduledTimeUtc"),
                "arrival_time": (flight.get("arrival") or {}).get("scheduledTimeUtc"),
                "status": flight.get("status"),
                "last_updated": datetime.now(berlin_tz)
            })
    if not records:
        return 0
    df = pd.DataFrame(records)
    with engine.begin() as conn:
        for row in df.to_dict(orient="records"):
            conn.execute(text("""
                INSERT INTO flights
                (icao, flight_number, airline, departure_time, arrival_time, status, last_updated)
                VALUES (:icao, :flight_number, :airline, :departure_time, :arrival_time, :status, :last_updated)
                ON DUPLICATE KEY UPDATE
                    status=VALUES(status),
                    last_updated=VALUES(last_updated)
            """), row)
    return len(records)

# ---------- Cloud Run / HTTP Entrypoint ----------
@app.route("/", methods=["GET"])
def update_pipeline():
    engine = get_db_engine()
    cities_df = get_cities(engine)
    total = {"airports":0, "weather":0, "flights":0}

    for _, city in cities_df.iterrows():
        cid = city["city_id"]
        # airports (idempotent)
        try:
            apj = fetch_airports(city["latitude"], city["longitude"])
            total["airports"] += insert_airports(apj, cid, engine)
        except Exception as e:
            app.logger.warning(f"Airport fetch/insert failed for {city['city']} : {e}")

        # weather
        try:
            wj = fetch_weather(city["city"])
            total["weather"] += insert_weather(wj, cid, engine)
        except Exception as e:
            app.logger.warning(f"Weather fetch/insert failed for {city['city']} : {e}")

        # flights for each airport in city
        try:
            icao_list = get_airports_icao(engine, cid)
            for icao in icao_list:
                fj = fetch_flights(icao)
                total["flights"] += insert_flights(fj, icao, engine)
        except Exception as e:
            app.logger.warning(f"Flights fetch/insert failed for city_id={cid} : {e}")

    return jsonify({"status":"ok", "summary": total}), 200

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
