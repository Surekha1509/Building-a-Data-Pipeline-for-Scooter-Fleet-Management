-- SQL schema for Gans fleet pipeline
CREATE TABLE IF NOT EXISTS cities (
    city_id INT PRIMARY KEY AUTO_INCREMENT,
    city VARCHAR(255) NOT NULL,
    country VARCHAR(100),
    latitude DECIMAL(10,6),
    longitude DECIMAL(10,6)
);

CREATE TABLE IF NOT EXISTS airports (
    icao VARCHAR(10) PRIMARY KEY,
    city_id INT,
    FOREIGN KEY (city_id) REFERENCES cities(city_id)
);

CREATE TABLE IF NOT EXISTS weather (
    weather_id INT PRIMARY KEY AUTO_INCREMENT,
    city_id INT,
    forecast_time DATETIME,
    temperature DECIMAL(5,2),
    forecast VARCHAR(255),
    rain_in_last_3h DECIMAL(6,2),
    wind_speed DECIMAL(6,2),
    data_retrieved_at DATETIME,
    FOREIGN KEY (city_id) REFERENCES cities(city_id)
);

CREATE TABLE IF NOT EXISTS flights (
    flight_id INT PRIMARY KEY AUTO_INCREMENT,
    icao VARCHAR(10),
    flight_number VARCHAR(50),
    airline VARCHAR(255),
    departure_time DATETIME,
    arrival_time DATETIME,
    status VARCHAR(50),
    last_updated DATETIME,
    FOREIGN KEY (icao) REFERENCES airports(icao)
);
